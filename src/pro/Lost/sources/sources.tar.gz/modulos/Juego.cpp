#include "Juego.h"

Juego* Juego::instance = 0;

// Instanciamos un objeto Juego si no hay uno creado antes , si lo esta ,  le devolvemos el ya instanciado
Juego* Juego::Instance() {
  if(instance == 0){
      instance = new Juego;
      instance->Inicializar();
  }
  return instance;
}

//Inicializamos el mundo
void Juego::Inicializar() {
  m = Mundo::Instance();
}

//Capturamos los eventos del juego
void Juego::event(sf::Event event,sf::RenderWindow &window){
  m->Event(event,window);
}

void Juego::update(sf::RenderWindow &window) {
  m->Update(window);
}

void Juego::draw(sf::RenderWindow &window){
  m->Draw(window);
}