#include "Animacion.h"

Animacion::Animacion(){
    //Constructor por defecto
}

Animacion::Animacion(string textura, int tamano, float vel){
    
    if(!texture.loadFromFile(textura)){
        cout << "No se ha podido cargar la textura (animacion)" << endl;
    }

    velAnim = vel;
    size = tamano;
}

void Animacion::colocarFrames(IntRect primero, IntRect ultimo){
    primFr = primero;
    ultFr = ultimo;
    miFrame = primero;

    sprite = Sprite(texture, miFrame);
    sprite.setOrigin(size/2, size/2);
}

void Animacion::update(Vector2f movimiento){
    float tiempo_pasado = clock.getElapsedTime().asSeconds();

    if(tiempo_pasado >= tiempo && animar){
        clock.restart();

        if(miFrame.left == ultFr.left){
            miFrame.left = primFr.left;
        }else{
            miFrame.left += size;
        }

        sprite.setTextureRect(miFrame);
    }

    sprite.move(movimiento /* *tiempo_pasado*/);
}

void Animacion::setPosition(Vector2f pos){
    sprite.setPosition(pos);
}

void Animacion::Draw(RenderWindow &window){
    window.draw(sprite);
}

void Animacion::Stop(){
    animar = false;
}

void Animacion::Play(){
    animar = true;
}
