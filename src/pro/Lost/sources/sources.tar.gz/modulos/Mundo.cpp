#pragma once 
#include "Mundo.h"

Mundo* Mundo::instance = 0;

Mundo* Mundo::Instance() {
  if(instance == 0){
    instance = new Mundo();
    std::cout << "Instancia mundo"; 
  }
  return instance;
}

Mundo::Mundo(){
  //Inicializaciones para la instancia
  std::cout << "Mundo iniciado.\n";
  j = new Jugador(100, 100, 0.2, 1);
  t = new Tienda();
  h = new Hud();
  monedas.reserve(5);
  enemies.reserve(5);
  //map = new Mapa(lvl);

  //Creacion de enemigos
  randomrow = rand() % 15 + 1;
  randomcol = rand() % 13 + 1;
  Enemigo* enemy = new Enemigo(randomcol*16, randomrow*16);
  enemies.push_back(enemy);
}

void Mundo::Event(sf::Event event,sf::RenderWindow &window){


  switch (event.type) {
    case sf::Event::Closed:
      
      Contexto::Instance()->quit();
      window.close();
    break;
    //case sf::Event::MouseButtonPressed:
    case sf::Event::KeyPressed:
          ///Verifico si se pulsa alguna tecla de movimiento
        /*if(Keyboard::isKeyPressed(Keyboard::W) || Keyboard::isKeyPressed(Keyboard::A) || Keyboard::isKeyPressed(Keyboard::S) || Keyboard::isKeyPressed(Keyboard::D)){
          j->animacion_actual->Play();
        }else{
          j->animacion_actual->Stop();
        }*/
      switch (event.key.code) {
      
        //Arriba
        case sf::Keyboard::W:
          j->Movimiento(1);
          if(j->Pulsada() == true){
            cout << "W pulsada" << endl;
          }
          break;
        //Abajo
        case sf::Keyboard::S:
          j->Movimiento(2);
          break;
        //Derecha
        case sf::Keyboard::D:
          j->Movimiento(4);
          break;
        //Izquierda
        case sf::Keyboard::A:
          j->Movimiento(3);
          break;

      default:
        std::cout << "Code " << event.key.code << std::endl;
      break;
    }
  }
}


void Mundo::Update(sf::RenderWindow &window){
  j->update();
  
}

void Mundo::Draw(sf::RenderWindow &window){
  //map->draw(window);
  j->draw(window);
  h->render(window,j);
  for(unsigned i = 0; i < enemies.size(); i++){
    enemies[i]->draw(window);
  }
}
