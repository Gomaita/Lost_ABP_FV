#include "HUD.h"
#include <iostream>

Hud::Hud() {
  //Cargamos la textura si hay un error se para la ejecucion
  if (!texH.loadFromFile("resources/hud/health_bar.png")) {
    std::cerr << "Error cargando la imagen health.png";
    exit(0);
  }

  if (!texC.loadFromFile("resources/hud/coin-HUD.png")) {
    std::cerr << "Error cargando la imagen coin.png";
    exit(0);
  }

  if (!texI.loadFromFile("resources/hud/inventario.png")) {
    std::cerr << "Error cargando la imagen inventario.png";
    exit(0);
  }

  //Instanciamos los sprites
  healthBar = sf::Sprite(texH);

  healthPoint = sf::Sprite(texH);

  manaBar = sf::Sprite(texH);

  manaPoint = sf::Sprite(texH);

  coin = sf::Sprite(texC);

  slot = sf::Sprite(texI);

  //Recortamos los sprites
  healthBar.setTextureRect(sf::IntRect(0,170,250,30));
  healthPoint.setTextureRect(sf::IntRect(30,170,10,35));

  manaBar.setTextureRect(sf::IntRect(0,170,250,30));
  manaPoint.setTextureRect(sf::IntRect(30,127,10,35));

  coin.setTextureRect(sf::IntRect(0,0,31,31));

  slot.setTextureRect(sf::IntRect(10,23,93,80));

  //Lo alojamos en pantalla
  healthBar.setPosition(20,20);
  manaBar.setPosition(20,50);
  coin.setPosition(1160,35);
  slot.setScale(0.5,0.5);
}


void Hud::render(sf::RenderWindow& w, Jugador* p){
  sf::Font f = sf::Font();
  if(!f.loadFromFile("resources/font/arial.ttf")){
    exit(0);
  }

    
  w.draw(healthBar);
  w.draw(manaBar);
  w.draw(coin);

  int puntoS=350;
  for(int i = 0; i < 6; i++){
    w.draw(slot);

    if(p->getInventory().size()>i){
      p->getInventory()[i].getSprite()->setPosition(puntoS,620);
      w.draw(*p->getInventory()[i].getSprite());
    }

    puntoS = puntoS+50;
    slot.setPosition(puntoS,620);
    if(i == 5){
        slot.setPosition(750,620);
        w.draw(slot);
    }
  }
    
  int puntoVida=59;
  int iteraciones = trunc((p->getHealth() * p->getMaxHealth()) / 100);

  if(p->getHealth()!=5){
    for(int i = 0; i<iteraciones; i++){
      healthPoint.setPosition(puntoVida,20);
      w.draw(healthPoint);
      puntoVida = puntoVida+9;
    }
  }

  int puntoMana = 49;
  int it = trunc((p->getMana() * p->getMaxMana()) / 100) + 1;

  if(p->getMana() != 5){
    for(int i =0 ; i<it;i++){
      manaPoint.setPosition(puntoMana,44);

      w.draw(manaPoint);
      puntoMana=puntoMana +9;
    }
  }

  //Dibujamos en texto cuantos puntos de vida tiene el jugador
  sf::Text t = sf::Text();
  t.setFont(f);
  t.setCharacterSize(17);
  std::ostringstream os;
  os << p->getHealth();
  t.setString(os.str());
  //Le establecemos el color
  t.setColor(sf::Color::White);
  t.setPosition(135,29);
  w.draw(t);

  //Dibujamos en texto cuantos puntos de mana tiene el jugador
  sf::Text t2 = sf::Text();
  t2.setFont(f);
  t2.setCharacterSize(17);
  std::ostringstream os2;
  os2 << p->getMana();
  t2.setString(os2.str());
  //Le establecemos el color
  t2.setColor(sf::Color::White);
  t2.setPosition(135,59);
  w.draw(t2);

  //Dibujamos en texto cuantas monedas tiene el jugador en todo momento
  sf::Text t3 = sf::Text();
  t3.setFont(f);
  t3.setCharacterSize(25);
  std::ostringstream os3;
  os3 << p->getCoins();
  t3.setString(os3.str());
  //Le establecemos el color
  t3.setColor(sf::Color::White);
  t3.setPosition(1200,34);
  w.draw(t3);
}