#include "Jugador.h"

#include <iostream>

Jugador::Jugador(int m, int v, float vel, int personaje) {
    health = 100;
    mana = 100;
    coins = 0;
    inventory.reserve(20);
    
    velocidad = vel;

    animando = false;

    jugador = RectangleShape(Vector2f(50.f, 70.f));
    jugador.setOrigin(50/2, 70/2);
    jugador.setPosition(200, 240);

    elegirJugador(personaje);

    for(int i = 0; i < 4; i++){
        movimiento[i] = false;
    }
}

void Jugador::elegirJugador(int n){

    if(n == 1){
        //Poner que animacion quiero elegir
        arriba = Animacion("./resources/Personajes/Protagonista_chico.png", 53, 0.5);
        abajo = Animacion("./resources/Personajes/Protagonista_chico.png", 53, 0.5);
        izquierda = Animacion("./resources/Personajes/Protagonista_chico.png", 53, 0.5);
        derecha = Animacion("./resources/Personajes/Protagonista_chico.png", 53, 0.5);

    }else if(n == 2){
        arriba = Animacion("./resources/Personajes/Protagonista_chica.png", 53, 0.5);
        abajo = Animacion("./resources/Personajes/Protagonista_chica.png", 53, 0.5);
        izquierda = Animacion("./resources/Personajes/Protagonista_chica.png", 53, 0.5);
        derecha = Animacion("./resources/Personajes/Protagonista_chica.png", 53, 0.5);
    }else if(n == 3){
        arriba = Animacion("./resources/Personajes/Protagonista_elfo.png", 53, 0.5);
        abajo = Animacion("./resources/Personajes/Protagonista_elfo.png", 53, 0.5);
        izquierda = Animacion("./resources/Personajes/Protagonista_elfo.png", 53, 0.5);
        derecha = Animacion("./resources/Personajes/Protagonista_elfo.png", 53, 0.5);
    }else if(n == 4){
        arriba = Animacion("./resources/Personajes/Protagonista_elfa.png", 53, 0.5);
        abajo = Animacion("./resources/Personajes/Protagonista_elfa.png", 53, 0.5);
        izquierda = Animacion("./resources/Personajes/Protagonista_elfa.png", 53, 0.5);
        derecha = Animacion("./resources/Personajes/Protagonista_elfa.png", 53, 0.5);
    }else{
        cout << "Elige una opción correcta" << endl;
    }

    //sf::IntRect(1 * 53, 2 * 78, 53, 78)
    arriba.colocarFrames(IntRect(0*53, 0*78, 53, 78), IntRect(2*53, 0*78, 53, 78));
    derecha.colocarFrames(IntRect(0*53, 1*78, 53, 78), IntRect(2*53, 1*78, 53, 78));
    abajo.colocarFrames(IntRect(0*53, 2*78, 53, 78), IntRect(2*53, 2*78, 53, 78));
    izquierda.colocarFrames(IntRect(0*53, 3*78, 53, 78), IntRect(2*53, 3*78, 53, 78));

    /*
        Otra forma de hacerlo
        sf::Vector2f aux = animacion_actual->getPosition();
        animacion_actual = &abajo;
        animacion_actual-> setPositon(aux);
    */

    animacion_actual = &abajo;
    animacion_actual->setPosition(jugador.getPosition());
}

void Jugador::update(){
    animacion_actual->update(Vector2f(posX, posY));
}


void Jugador::Movimiento(int n){
    posX = 0;
    posY = 0;

    if(n == 1 || n == 2 || n == 3 || n == 4){
        animacion_actual->Play();
    }else{
        animacion_actual->Stop();
    }

    switch (n)
    {
    case 1: 
        
        posY -= velocidad;
        cambiarAnimacion(&arriba);
        break;

    case 2: 
        posY += velocidad;
        cambiarAnimacion(&abajo);
        break;
    
    case 3:
        posX -= velocidad;
        cambiarAnimacion(&izquierda);
        break;
    
    case 4:
        posX += velocidad;
        cambiarAnimacion(&derecha);
        break;
    }

    jugador.move(posX, posY);
    
}



void Jugador::cambiarAnimacion(Animacion* animacion){
    if(animacion_actual != animacion){
        animacion_actual = animacion;
        animacion_actual->setPosition(jugador.getPosition());
    }
}

void Jugador::getDamage(int d){
    if(health - d < 0)
        health = 0;
    else
         health = health - d;
}

void Jugador::getHeal(int h){
    if(health + h > 100)
        health = 100;
    else
        health = health + h;
}

int Jugador::getHealth(){
    return health;
}

int Jugador::getMaxHealth(){
    return maxHealth;
}

int Jugador::getCoins(){
    return coins;
}

void Jugador::gainCoin(int n){
    coins = coins + n;
}

void Jugador::spendCoin(int n){
    if(coins-n < 0){
        coins = 0;
    }
    else
        coins = coins -n;
}

void Jugador::spendMana(int d){
    if(mana - d < 0)
        mana = 0;

    else
         mana = mana - d;
}

void Jugador::recoverMana(int h){
    if(mana + h > 100)
        mana = 100;
    
    else
        mana = mana + h;
}

int Jugador::getMana(){
    return mana;
}

int Jugador::getMaxMana(){

    return maxHealth;
}

void Jugador::draw(sf::RenderWindow &window){
    animacion_actual->Draw(window);
}

bool Jugador::Pulsada(){
    string s = "";

    Event event;

    s += event.key.code;

    if(s != ""){
        return true;
    }else{
        return false;
    }
}