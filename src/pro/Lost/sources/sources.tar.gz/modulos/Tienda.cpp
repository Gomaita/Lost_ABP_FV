#include "Tienda.h"
#include <iostream>

Tienda::Tienda() {
  //Reservamos memoria para el vector y generamos los objetos de la tienda
  products.reserve(5);

  //Cargamos el sprite del icono de la moneda para ponerla junto al valor 
  t = new sf::Texture;
  if (!t->loadFromFile("resources/hud/coin-HUD.png")) {
    std::cerr << "Error cargando la imagen coin-Consumable.png";
    exit(0);
  }

  coin = new sf::Sprite(*t);
  coin->setTextureRect(sf::IntRect(0,0,31,31));
  coin->setScale(0.5,0.5);

  genItems();
}

//Por cada item llamamos a su render
void Tienda::render(sf::RenderWindow &w){
  int pox=250;
  int poy=120;
  int poyV=90;
  int poxC=260;
  int poyC=95;
  
  sf::Font f=sf::Font();
  if(!f.loadFromFile("resources/font/font.ttf")){
      exit(0);
  }
  
  if(isDrawable){
    for(std::size_t i = 0;i < products.size(); i++){
      //Dibujamos el valor del objeto
      sf::Text t = sf::Text();
      t.setFont(f);
      t.setCharacterSize(17);
      std::ostringstream os;
      os << products[i].getValue();
      t.setString(os.str());
      //Le establecemos el color
      t.setColor(sf::Color::White);
      t.setPosition(pox,poyV);
      w.draw(t);
      products[i].getSprite()->setPosition(pox,poy);
      //llamamos al render de item
      products[i].render(w);
      //dibujamos el icono de la moneda
      coin->setPosition(poxC,poyC);
      w.draw(*coin);
      pox = pox+90;
      poxC = poxC+90;
    }
  }
}

void Tienda::genItems(){
  
  int num;
  prod p;
 
  //Por cada objeto disponible de la tienda lo creamos
  for(int i=0;i<niv;i++){
    if(!products.empty())
    {
      //Con esto evitamos que hayan objetos repetidos en la tienda
      bool repite=true;
      while(repite){
        srand(num);
        num = rand()%3;     //Generamos un numero aleatorio del 0 al 2 que correspondera con el tipo de objeto
        p = (prod)num;
        
        for(std::size_t z=0; z<products.size(); z++){
          if(products[i].getTipo() == p)
            repite=true;
          else  
            repite=false;
        }
      }
    }
    else{
        srand(num);
      num = rand()%3;     
      p = (prod)num;

    }
    products.push_back(Item(2,p));
  }
}

