#include "Menu.h"
#include "MEstados.h"

Menu* Menu::instance = 0;

Menu* Menu::Instance(sf::RenderWindow &window) {
    if(instance == 0){
      instance = new Menu(window);
    }
    return instance;
}

void Menu::Inicializar(){
    menu.reserve(MAX_NUMBER_ITEMS);

}

Menu::Menu(sf::RenderWindow& window){
    if(track.openFromFile("resources/sound/underground.ogg")){
        std::cout << "Error en audio" << std::endl;
    }

    track.setVolume(65.0);
    track.setLoop(true);
    track.play();

    if(!font.loadFromFile("resources/font/font.ttf")){
         std::cout << "Error al cargar la fuente" << std::endl;
    }

    selectedItem = 0;

    menu.push_back(sf::Text());
    
    menu.back().setFont(font);
    menu.back().setColor(sf::Color::Red);
    menu.back().setString("New game");
    menu.back().setPosition(sf::Vector2f(width/2.40, height/(MAX_NUMBER_ITEMS + 1) * 1));

    menu.push_back(sf::Text());
    
    
    menu.back().setFont(font);
    menu.back().setColor(sf::Color::Red);
    menu.back().setString("Game mode");
    menu.back().setPosition(sf::Vector2f(width/2.40, height/(MAX_NUMBER_ITEMS + 2.4) * 2));

    menu.push_back(sf::Text());
    menu.back().setFont(font);
    menu.back().setColor(sf::Color::Red);
    menu.back().setString("Options");
    menu.back().setPosition(sf::Vector2f(width/2.40, height/(MAX_NUMBER_ITEMS + 3.2) * 3));

    menu.push_back(sf::Text());
    menu.back().setFont(font);
    menu.back().setColor(sf::Color::Red);
    menu.back().setString("Exit");
    menu.back().setPosition(sf::Vector2f(width/2.40, height/(MAX_NUMBER_ITEMS + 3.8) * 4));

    menu.push_back(sf::Text());
    menu.back().setFont(font);
    menu.back().setColor(sf::Color::Red);
    menu.back().setString("Difficulty: Easy");
    menu.back().setPosition(sf::Vector2f(width/2.40, height/(MAX_NUMBER_ITEMS + 2.4)* 2));

    menu.push_back(sf::Text());
    menu.back().setFont(font);
    menu.back().setColor(sf::Color::Red);
    menu.back().setString("Difficulty: Hard");
    menu.back().setPosition(sf::Vector2f(width/2.40, height/(MAX_NUMBER_ITEMS + 3.2) * 3));


    menu.push_back(sf::Text());
    menu.back().setFont(font);
    menu.back().setColor(sf::Color::Red);
    menu.back().setString("Resolution:");
    menu.back().setPosition(sf::Vector2f(width/2.40, height/(MAX_NUMBER_ITEMS + 3.2) * 3));
}

Menu::~Menu(){

}

void Menu::draw(sf::RenderWindow &window){
    
    
    switch(modo){
    //menu principal
    case -1:
        for(int i = 0; i < 4; i++){
                window.draw(menu[i]);
        }
    break;

    case 0:
        for(int i = 4; i < 6; i++){
                window.draw(menu[i]);
        }

     break;

    case 1:
        for(int i = 6; i < 7; i++){
                window.draw(menu[i]);
        }

      break;

    } 
}

void Menu::event(sf::Event event, sf::RenderWindow &window){
   
    switch(event.type){
        case sf::Event::Closed: 
            track.stop();
            window.close();
            break;
        case sf::Event::KeyPressed:
            switch (event.key.code) {
                //Arriba
                case sf::Keyboard::Up:
                {
                    if(modo == 0){
                        if(selectedItem - 1 < 4){
                            selectedItem = 5;
                        }else{
                             
                            selectedItem--;
                        }
                    }else if(modo == 1){
                        if(selectedItem - 1 < MAX_NUMBER_ITEMS - 1){
                            selectedItem = 6;
                        }else{
                            selectedItem--;
                        }
                    }

                    else{
                    
                         if(selectedItem - 1 < 0){
                             selectedItem = 3;
                         }else{
                             selectedItem--;
                         }
                    }
                }
                break;
                //Abajo
                case sf::Keyboard::Down:
                    {
                        if(modo == 0){
                            if(selectedItem + 1 > 5){
                                selectedItem = 4;
                            }
                            else{
                                selectedItem++;
                            }
                        }
                        else if(modo == 1){
                            if(selectedItem - 1 < MAX_NUMBER_ITEMS - 1){
                                selectedItem = 6;
                            }else{
                                selectedItem++;
                            }
                        }
                        
                        else{
                             if(selectedItem + 1 > 3){
                                 selectedItem = 0;
                             }else{
                                 selectedItem++;
                             }
                        }
                    }
                break; 
                //Enter
                case sf::Keyboard::Return:
                    std::cout << "Espacio/Enter\n";
                    switch(selectedItem){
                        case 0: //New game
                            {
                                Contexto *c = Contexto::Instance();
                                c->ChangeState(Juego::Instance());
                            }
                            break;
                            
                        case 1: //Game mode
                            {modo = 0;
                            selectedItem = 4;}
                            break;
                        case 2: //Options
                            {modo = 1;
                            selectedItem = 6;}
                            break;
                        case 3: //Exit

                             track.stop();
                             window.close();

                            break;
                        default:
                            break;
                    }
                break; 

                case sf::Keyboard::Escape:

                if(modo==0 || modo==1){
                    modo=-1;
                    selectedItem=0;
                }

                else{
                     track.stop();
                     window.close();
                }



                break;

                default:
                    break;
            }
            break;
        default:
            break;
    }
}

void Menu::update(sf::RenderWindow &window){
    for(int x = 0; x < MAX_NUMBER_ITEMS; x++){
        if(x == selectedItem){
            menu[x].setColor(sf::Color::Yellow);
        }else{
            menu[x].setColor(sf::Color::Red);
        }
    }
}
