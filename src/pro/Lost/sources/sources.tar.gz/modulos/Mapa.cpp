#include "Mapa.h"

Mapa::Mapa(int nivel){
    nivelactual = nivel;
    void leerMapa(int nivel);
    void setAtributos();
    void leerDatos();
    void cargarTexturas();
    void creaMapaSprites();
}
void Mapa::estructurarmapa(){
    int random;

    srand (time(NULL));

    for(int contadorsalas = 0; contadorsalas == 15; contadorsalas++){ //ESPECIFICAR TAMAÑO ARRAY SALAS EN CONTADOR SALAS
        random = rand() % 3 + 1;
        mapa1.push_back(random);

    }
}

Mapa::~Mapa(){

    for(int i=0; i<_numLayers; i++){
        for(int j=0; j<_height; j++){
            delete _tilemap[i][j];
        }
        delete _tilemap[i];
    }
    delete _tilemap;

    for(int l=0; l<_numLayers; l++){
        for(int y=0; y<_height; y++){
            for(int x=0; x<_width; x++){
                if(_tilemapSprite[l][y][x] != NULL){
                    _tilemapSprite[l][y][x] = NULL;
                    delete _tilemapSprite[l][y][x];
                }
            }
            delete _tilemapSprite[l][y];
        }
        delete _tilemapSprite[l];
    }
    delete _tilemapSprite;
}

void Mapa::leerDatos(){
    std::cout << "Width: " << _width << endl;
    std::cout << "Height: " << _width << endl;
    std::cout << "Imagen Tileset: " << img << endl;
    std::cout << "Filename: " << filename << endl;
    std::cout << "Capa: " << layer << endl;
}

void Mapa::leerMapa(int nivel){
    if(nivel != 0){
        stringstream ss;
        ss << nivel;
        string str = ss.str();
        int variante = mapa1[nivel];
        stringstream ss2;
        ss2 << variante;
        string str2 = ss2.str();
        
        //string fichero = "resources/mapa/tmx/mapa_"+str+"_"+str2+".tmx"; //Nombre de mapas tiene que ser: mapa_X_Y.tmx  x= nivel(id), y = variante para mapa
       // doc.LoadFile(fichero.c_str());
       doc.LoadFile("resources/mapa/tmx/mapa-bea.tmx");
      
    }
    else{
        doc.LoadFile("resources/mapa/tmx/mapa_0.tmx");
    }
    
    //Tamaño del mapa y de los tiles
    map = doc.FirstChildElement("map");
}

void Mapa::setAtributos(){
    std::cerr << "\nLectura de atributos del Tilemap" << endl;
    map->QueryIntAttribute("width", &_width);
    map->QueryIntAttribute("height", &_height);
    map->QueryIntAttribute("tilewidth", &_tileWidth);
    map->QueryIntAttribute("tileheight", &_tileHeight);
    
    //Carga de TMX con TinyXML - Imagen del tileset
    img = map->FirstChildElement("tileset")->FirstChildElement("image");
    filename = img->Attribute("source");
    layer = map->FirstChildElement("layer");
}

void Mapa::cargarTexturas(){
    // ****** CREA LA TEXTURA *********** //
    if(!_tilesetTexture.loadFromFile(filename)) {
            std::cerr << "No ha podido cargar las texturas" << std::endl;
            exit(0);
        }

    //Capas de mi TMX
    while(layer){
        _numLayers++;
        layer = layer->NextSiblingElement("layer");
    }

    //Reservamos memoria para mapa
    std::cout << "Reservamos memoria para el nº de capas" << endl;
    layer = map->FirstChildElement("layer"); //Apunta a la primera capa
    _tilemap = new int**[_numLayers]; //Asignamos el nº de capas

    //Asignación de capas
    for(int i = 0; i < _numLayers; i++) {
        // height of the tilemap
        _tilemap[i] = new int*[_height];
        for(int j = 0; j < _height; j++) {
            // width of the tilemap
            _tilemap[i][j] = new int[_width];
        } 
    }

    //Cargando los GIDs de multiples capas
    //data = map->FirstChildElement("layer")->FirstChildElement("data")->FirstChildElement("tile");

    int cont = 0; //Capa en la que nos encontramos en el bucle
    while(layer){
        data = layer->FirstChildElement("data")->FirstChildElement("tile");
        while(data){
            for(int i = 0; i < _height; i++){
                for(int j = 0; j < _width; j++){
                    data->QueryIntAttribute("gid", &_tilemap[cont][i][j]);
                    //Avanzo al siguiente tag
                    data = data->NextSiblingElement("tile");
                }
            }
        }
        layer = layer->NextSiblingElement("layer");
        cont++;
    }
    
    //Cargamos el mapa
    std::cout << "Numero de layers: " << _numLayers << endl;
}

void Mapa::creaMapaSprites(){
    std::cout << "Reserva de Sprites" << endl;
    _tilemapSprite = new sf::Sprite***[_numLayers];

    for(int l=0; l<_numLayers; l++){
        _tilemapSprite[l] = new sf::Sprite**[_height];
        for(int y=0; y<_height; y++){
            _tilemapSprite[l][y] = new sf::Sprite*[_width];
            for(int x=0; x<_width; x++){
                _tilemapSprite[l][y][x] = new sf::Sprite;
            }
        }
    }

    // ****** SACAR COLUMNAS Y FILAS DE LA TEXTURA ************//
    int columnas = _tilesetTexture.getSize().x / _tileWidth;
    int filas = _tilesetTexture.getSize().y / _tileHeight;
    /*
    columnas = 32;
    filas = 32; */
    cout << "x: " << _tilesetTexture.getSize().x << endl;
    cout << "y: " << _tilesetTexture.getSize().y << endl;
    cout << "Columnas: " << columnas << endl << "Filas: "<< filas << endl; 
    // ****** CREAR EL SPRITE CON LA TEXTURA DE ARRIBA *********** //
    //Tile especifico de mi tileset - Formado por cada uno de los elementos de mi tileset
    _tilesetSprite = new sf::Sprite[filas*columnas];

    int n = 0;

    for(int y = 0; y < filas; y++) {
        for(int x = 0; x < columnas; x++) {
            _tilesetSprite[n].setTexture(_tilesetTexture);
            _tilesetSprite[n].setTextureRect(sf::IntRect(x*_tileWidth, y*_tileHeight, _tileWidth, _tileHeight));
            //std::cout << _tilesetSprite[n].getTextureRect().left << endl;
            n++;
        }
    }
    
    for(int l = 0; l < _numLayers; l++){
        for(int y= 0; y < _height; y++){
            for(int x = 0; x < _width; x++){
                int gid = _tilemap[l][y][x]-1;
                //Ahora empiza asignar los sprites a los (gids)
                
                if(gid > 0 && gid < _width*_height) {
                    //Si fuera 0 no creo sprite
                    _tilemapSprite[l][y][x] = new sf::Sprite(_tilesetTexture,_tilesetSprite[gid].getTextureRect());
                    _tilemapSprite[l][y][x]->setPosition(x*_tileWidth, y*_tileHeight);
                    //std::cout << x*_tileWidth << " + " << y*_tileHeight << endl;
                }else{
                    _tilemapSprite[l][y][x] = NULL;
                }
            }
        }
    }

    //Comprobar si está fuera de mi spritesheet
}

sf::Vector2f Mapa::getViewPosition()
{
    tinyxml2::XMLElement* object;

    object = map->FirstChildElement("objectgroup");
    std::string nameObject; 
    int x = 0; int y = 0;

    while(object) {
        nameObject = (std::string)object->Attribute("name");
        
        if(nameObject.compare("view") == 0) {
            object = object->FirstChildElement("object");

            object->QueryIntAttribute("x", &x);
            object->QueryIntAttribute("y", &y);

            break;

        } else {
            object = object->NextSiblingElement("objectgroup");
        }
    }

    return sf::Vector2f(x, y);
}

void Mapa::draw(sf::RenderWindow& window){

    for(int l=0; l<_numLayers; l++){
        for(int y=0; y < _height; y++){
            for(int x=0; x < _width; x++){
                if(_tilemapSprite[l][y][x] != NULL){
                    window.draw(*(_tilemapSprite[l][y][x]));
                }
            }
        }
    }
}

void Mapa::setActiveLayer(int layer){
    _activeLayer = layer;
}


void Mapa::mapaColisiones(){
// Creamos el mapa de colisiones con los tiles para despues comprobarlo

// Para la capa 2 que es la de las colisiones
    setActiveLayer(2);
    //inicializar el mapa de colisiones
    mapacolisiones = new bool*[_height];
    for(int i=0; i<_height; i++){
        mapacolisiones[i] = new bool[_width];
    }

    //Recorremos y guardamos la capa en la matriz de colisiones
    while(data){
        for(int i = 0; i < _height; i++){
            for(int j = 0; j < _width; j++){
                data->QueryIntAttribute("gid", &_tilemap[_activeLayer][i][j]);
                if(_tilemap[_activeLayer][i][j] == 0){
                    mapacolisiones[i][j] = false;
                }
                else{
                    mapacolisiones[i][j] = true;
                }
            }
        }
    }
}






