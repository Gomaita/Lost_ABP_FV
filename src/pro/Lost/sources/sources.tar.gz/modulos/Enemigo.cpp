#include "Enemigo.h"

Enemigo::Enemigo(float a, float b){
    hitbox = sf::RectangleShape(sf::Vector2f(50,70)); 
    x = a;
    y = b;
    hitbox.setPosition(x,y);
    hitbox.setOrigin(50/2, 70/2);
    hitbox.setFillColor(sf::Color::Blue);
    for(int i = 0; i < 4; i++) {
        this->movement[i] = false;
    }
    loadAnimation();
    actual = &down;
}

Enemigo::~Enemigo(){

}

void Enemigo::loadAnimation(){
    up.colocarFrames(IntRect(0*53, 0*78, 53, 78), IntRect(2*53, 0*78, 53, 78));
    right.colocarFrames(IntRect(0*53, 1*78, 53, 78), IntRect(2*53, 1*78, 53, 78));
    down.colocarFrames(IntRect(0*53, 2*78, 53, 78), IntRect(2*53, 2*78, 53, 78));
    left.colocarFrames(IntRect(0*53, 3*78, 53, 78), IntRect(2*53, 3*78, 53, 78));
}

void Enemigo::update(){

}

void Enemigo::direction(){

}

void Enemigo::move(){

}

void Enemigo::getDamage(){

}

void Enemigo::setPosition(){
    hitbox.setPosition(x, y);
    actual->setPosition(sf::Vector2f(x, y));
}

void Enemigo::kill(){

}

//Para que se mueva en x direccion
void Enemigo::changeAnimation(Animacion* newAnimation)
{
    if(newAnimation != actual) {
        actual = newAnimation;
        actual->setPosition(hitbox.getPosition());
    }
}

void Enemigo:: draw(sf::RenderWindow& window){
    actual->Draw(window);
    //std::cout << "Te dibujas o k - draw de Enemigo.\n";
}