#include "Moneda.h"

#include <iostream>

Moneda::Moneda(int v , int px, int py) {
  value = v;
  posX = px;
  posY = py;

  if (!t.loadFromFile("resources/hud/coin-HUD.png")) {
    std::cerr << "Error cargando la imagen coin-Consumable.png";
    exit(0);
  }

  s.setTexture(t);
  s.setTextureRect(sf::IntRect(0,0,31,31));
  s.setScale(0.8,0.8);
  s.setPosition(posX,posY);
}


void Moneda::render(sf::RenderWindow &w){
    if(!isTaken)
        w.draw(s);
}



