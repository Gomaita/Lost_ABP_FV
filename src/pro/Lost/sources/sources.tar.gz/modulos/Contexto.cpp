#include "Contexto.h"
#include "MEstados.h"

Contexto* Contexto::pinstance = 0;

Contexto* Contexto::Instance() {
    if(pinstance == 0){
        pinstance = new Contexto;
    }
    return pinstance;
}

void Contexto::Inicializar(){
    this->cambio = true;
    mEstados.reserve(10);
}

void Contexto::ChangeState(MEstados* s){ 
    //Almacena e inicia el nuevo estado
    std::cout << "\nTamaño pila de estados: " << this->mEstados.size() << "\n";	
    this->mEstados.push_back(s);
    std::cout << "Cambio de estado. \n";
    this->mEstados.back()->Inicializar();
    std::cout<<this->mEstados.size()<<"\n";

}
void Contexto::event(sf::Event event, sf::RenderWindow &window){
    this->mEstados.back()->event(event, window);
}
void Contexto::update(sf::RenderWindow &window){
    //Dejar al estado actualizar el juego
    this->mEstados.back()->update(window);
}
void Contexto::draw(sf::RenderWindow &window){
    // let the state draw the screen
    window.clear();
    mEstados.back()->draw(window);
    window.display();
}
