#include "Item.h"

#include <iostream>

Item::Item(int v,prod tip) {
  t = new sf::Texture;
  
  switch (tip){
    case 0:
      if (!t->loadFromFile("resources/Armas/espada_larga.png")) {
        std::cerr << "Error cargando la imagen : espada_larga";
        exit(0);
      }
    break;

    case 1:
      if (!t->loadFromFile("resources/Armas/espada_oscura.png")) {
        std::cerr << "Error cargando la imagen : espada_oscura" ;
        exit(0);
      }
    break;

    case 2:
      if (!t->loadFromFile("resources/Armas/espada.png")) {
        std::cerr << "Error cargando la imagen : espada" ;
        exit(0);
      }
    break;
  }

  s = new sf::Sprite(*t);
  s->setTextureRect(sf::IntRect(0,8,20,20));
  s->scale(2,2);
  //En el caso de la espada grande tengo que recortarla de otra forma
  if(tip == 0)
    s->setTextureRect(sf::IntRect(3,12,19,20));

  tipo = tip;
  value = v;
}

void Item::render(sf::RenderWindow &w){
  w.draw(*s);
}



