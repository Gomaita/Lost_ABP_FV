#pragma once

#include <SFML/Graphics.hpp>
#include "Jugador.h"
#include <cmath>
#include <sstream>


class Hud{

   private:
      sf::Texture texH;
      sf::Texture texC;
      sf::Texture texI;
      sf::Sprite healthBar;
      sf::Sprite healthPoint;
      sf::Sprite manaBar;
      sf::Sprite manaPoint;
      sf::Sprite coin;
      sf::Sprite slot;

   public:
      Hud();
      void render(sf::RenderWindow& w,Jugador* p);
};