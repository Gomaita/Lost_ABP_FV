#pragma once
#include <SFML/Graphics.hpp>
#include <string>
#include <iostream>

typedef enum prod{

      espada_grande,
      espada_media,
      espada_pequena,

   }prod;

struct Item{
   private:
   prod tipo;
   
    bool isEquiped=false;
    bool isWear=false;
    int value = 0;
    sf::Texture *t;
    sf::Sprite *s;
  

    
    public:
     Item(int v,prod t);
     bool getEquiped(){
        return isEquiped;
     }

     bool getWear(){
        return isWear;
     }

     void render(sf::RenderWindow &w);
     sf::Sprite* getSprite(){
        return s;
     } 
     void free(){
        delete s;
        delete t;
       
     }

      int getValue(){
         return value;
      }
     void setEquiped(bool t){
        isEquiped=t;
     }

     prod getTipo(){
        return tipo;
     }

      void setWear(bool t){
        isWear=t;
     }

     
};