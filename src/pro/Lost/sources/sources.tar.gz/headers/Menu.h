#pragma once
#include <string>
#include <iostream>
#include "SFML/Graphics.hpp"
#include <SFML/Audio.hpp>
#include <vector>

#include "MEstados.h"
#include "Juego.h"
#include "Contexto.h"
#define width 1024
#define height 720
#define MAX_NUMBER_ITEMS 10

class Menu : public MEstados {
  private:
    int selectedItem;
    static Menu* instance;
    sf::Font *f;
    sf::Font font;
    sf::Font *title;
    std::vector<sf::Text> menu;
    sf::Text *play;
    sf::Text *exit;
    int seleccion = 0;
    sf::Texture *texfondo;
    sf::Sprite *sprfondo;
    sf::Texture *texopciones;
    sf::Sprite *spropciones;
    sf::RenderWindow *window;

     int modo = -1;

    sf::Music track;

    sf::Mouse *mouse;

  public:
    Menu(sf::RenderWindow& window);
    ~Menu();
    void Inicializar();
    static Menu* Instance(sf::RenderWindow &window);
    void pause();
    void event(sf::Event event,sf::RenderWindow &window);
    void resume();
    void update(sf::RenderWindow &window);
    void draw(sf::RenderWindow &window);
    void loadMenu();
  
  protected:
    void cargaRecursos();
};
