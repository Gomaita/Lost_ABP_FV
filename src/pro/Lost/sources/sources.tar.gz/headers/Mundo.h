#pragma once
#include "Jugador.h"
#include "Enemigo.h"
#include "Moneda.h"
#include "Tienda.h"
#include "HUD.h"
#include "Mapa.h"
#include "Motor.h"
#include "Contexto.h"
#include <vector>

class Mundo{
    private: 
        static Mundo* instance;
        Jugador* j;
        Hud* h;
        Tienda* t;
        std::vector<Enemigo*> enemies;
        std::vector<Moneda*> monedas;
        Mapa* map;
        int dif = 0, lvl = 1;
        float randomrow, randomcol;
        
    public:
        Mundo();
        Mundo(const Mundo & );
        Mundo &operator= (const Mundo & );
        static Mundo* Instance();
        void Event(sf::Event event,sf::RenderWindow &window);
        void Update(sf::RenderWindow &window);
        void Draw(sf::RenderWindow &window);
};
