#include "Animacion.h"

class Enemigo{
    private:
        sf::RectangleShape hitbox;
        enum MOV {UP, DOWN, LEFT, RIGHT};
        bool movement[4];
        sf::Clock clock;
        int x,y;
        int posX, posY;
        float speed = 1.f;
        std::string textura = "./resources/Personajes/sprites.png";

        Animacion *actual;
        Animacion left = Animacion(textura, 16, 0.15f);
        Animacion right = Animacion(textura, 16, 0.15f);
        Animacion up = Animacion(textura, 16, 0.15f);
        Animacion down = Animacion(textura, 16, 0.15f);

    public:
        Enemigo(float x, float y);
        virtual ~Enemigo();
        void loadAnimation();
        void update();
        void direction();
        void move();
        void getDamage();
        void setPosition();
        void kill();
        void changeAnimation(Animacion* newAnimation);
        void draw(sf::RenderWindow& window);
        sf::FloatRect getGlobalBounds(){return hitbox.getGlobalBounds();};
        sf::Vector2f getPosition(){return hitbox.getPosition();};
};