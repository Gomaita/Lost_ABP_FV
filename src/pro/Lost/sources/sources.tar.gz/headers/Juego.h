#pragma once

#include <string>
#include <iostream>
#include "Mapa.h"
#include "Mundo.h"
#include "MEstados.h"

class Juego : public MEstados{
    private : 
        static Juego* instance;
        Mundo* m;
        
    public:
        void Inicializar();
        static Juego* Instance();
        void event(sf::Event event,sf::RenderWindow &window);
        void update(sf::RenderWindow &window);
        void draw(sf::RenderWindow &window);
};