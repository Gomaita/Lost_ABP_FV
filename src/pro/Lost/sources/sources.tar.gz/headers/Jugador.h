#pragma once
#include <vector>
#include "Item.h"
#include <SFML/Graphics.hpp>
#include "Animacion.h"

using namespace sf;
using namespace std;

class Jugador{
   private:
      int health;
      const int maxHealth = 20;
      const int maxMana = 20;
      int mana;
      int coins;

      int tam_x = 53;
      int tam_y = 78;

      float velocidad;

      std::vector<Item> inventory;
      sf::Texture* tex;
      sf::Sprite* s;


      float posX, posY;

      bool animando;
      bool movimiento[4];
      enum dir{UP, DOWN, LEFT, RIGHT};

      RectangleShape jugador;

   public:
      Jugador(int m, int v, float vel, int personaje);
      void getDamage(int d);

      std::vector<Item>& getInventory(){
         return inventory;
      }

      void setInventory(std::vector<Item> iv){
         inventory = iv;
      }

      void getHeal(int h);
      int getHealth();
      int getMaxHealth();
      void gainCoin(int n);
      void spendCoin(int n);
      void spendMana(int d);
      void recoverMana(int h);
      int getMana();
      int getMaxMana();
      int getCoins();
      void draw(sf::RenderWindow &window);
      void elegirJugador(int num);
      void Movimiento(int n);
      void cambiarAnimacion(Animacion* animacion);
      void update();

      bool Pulsada();

      Animacion* animacion_actual;
      Animacion arriba, abajo, izquierda, derecha;
};