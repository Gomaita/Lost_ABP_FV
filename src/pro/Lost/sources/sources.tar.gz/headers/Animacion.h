#pragma once
#include "SFML/Graphics.hpp"
#include <iostream>

using namespace std;
using namespace sf;

class Animacion{
    public:
        Animacion();
        Animacion(string textura, int tamano, float vel);
        void colocarFrames(IntRect primero, IntRect ultimo);
        void update(Vector2f movimiento);
        void Draw(RenderWindow &window);
        void setPosition(Vector2f pos);
        void Stop();
        void Play();

    private:
        Texture texture;
        IntRect primFr;
        IntRect ultFr;
        IntRect miFrame;

        float tiempo;
        float velAnim;

        int size;

        bool animar = true;

        Sprite sprite;

        sf::Clock clock;
};
