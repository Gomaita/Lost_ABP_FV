#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <iostream>
#include "tinyxml2.h"
#include <string>
#include <iostream>
#include <sstream>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include "math.h"
using namespace sf;
using namespace tinyxml2;
using namespace std;

class Mapa{
    private:
        //Variables para el mapa
        tinyxml2::XMLDocument doc;
        tinyxml2::XMLElement* map;
        tinyxml2::XMLElement* img;
        tinyxml2::XMLElement* layer;
        tinyxml2::XMLElement* data;
        int _width, _height, _tileWidth, _tileHeight;
        int _numLayers;
        std::vector<int> mapa1;
        int nivelactual;
        int num = 0; //Nº de capas del tileset
        const char *filename;
        int*** _tilemap; //GIDs de los tiles del mapa
        sf::Sprite**** _tilemapSprite;
        sf::Sprite* _tilesetSprite;
        Texture _tilesetTexture;

    public: 
        Mapa(int nivel);
        ~Mapa();
        
        void estructurarmapa();
        void leerMapa(int nivel);
        void setAtributos();
        void cargarTexturas();
        void creaMapaSprites();
        void leerDatos();
        void draw(RenderWindow&);
        sf::Vector2f getViewPosition();
        void mapaColisiones();
        bool **mapacolisiones;
        void setActiveLayer(int layer);
        int _activeLayer;
        
        
};       


