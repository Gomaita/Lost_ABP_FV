#pragma once
#include <SFML/Graphics.hpp>
#include <string>
#include <vector>
#include "Item.h"
#include <sstream>
#include "Jugador.h"

class Tienda{
   
   private:
      bool isDrawable=false;
      std::vector <Item> products;
      sf::Texture *t;
      sf::Sprite *coin;
      sf::Font f;
   
    public:
      Tienda();
      void genItems();
      void render(sf::RenderWindow &w);
      bool getDrawable(){
         return isDrawable;
      }
      int niv=2; //Nivel de la tienda que corresponde al numero de objetos que haya en la tienda
      void setDrawable(bool b){
         isDrawable = b;
      }
      std::vector<Item>& getItems(){
            return products;
      };
      //Liberamos memoria
      void free(){
         for(std::size_t i=0;i<products.size();i++){
            delete t;
            delete coin;
               products[i].free();
         }
      }
      void buyItem(Jugador& p,sf::RenderWindow& w);
};