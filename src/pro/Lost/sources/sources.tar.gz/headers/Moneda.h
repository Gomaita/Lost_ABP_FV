#pragma once
#include <SFML/Graphics.hpp>

class Moneda{


   private:
    int value;
    int posX,posY;
    bool isTaken=false;          //este valor indica si la moneda ha sido cogida por el player para borrarla cuando toque de la escena
    sf::Texture t;
    sf::Sprite s;

    
    public:
     Moneda(int v, int px,int py);
     int getValue(){
        return value;
     }
     void render(sf::RenderWindow &w);
     const sf::Sprite& getSprite(){
        return s;
     } 

     void setTaken(bool t){
        isTaken=t;
     }

     
};